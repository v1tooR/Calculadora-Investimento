function simulateRates() {
    return {
        inflationRate: 0.045,  // Taxa de inflação atualizada
        /*cdbRate: 11.0,  // Taxa do CDB atualizada
        dollarRate: 0.75,  // Taxa do dólar atualizada
        savingsRate: 0.25  // Taxa da poupança atualizada*/
    };
}

function formatCurrency(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function parseCurrency(value) {
    return parseFloat(value.replace(/\D/g, '')) / 100;
}

function clearFields() {
    document.getElementById('initialAmount').value = '';
    document.getElementById('monthlyAmount').value = '';
    document.getElementById('investmentTime').value = '';
    document.getElementById('timeUnit').value = 'months';
    document.getElementById('interestRate').value = '';
    document.getElementById('rateType').value = 'monthly';
    document.getElementById('finalValue').innerText = '';
    document.getElementById('totalInvested').innerText = '';
    document.getElementById('totalInterest').innerText = '';
    document.querySelector('#breakdownTable tbody').innerHTML = '';
    document.getElementById('resultsDiv').style.display = 'none';
}

function applyCurrencyMask(element) {
    let value = element.value.replace(/\D/g, '');
    value = (parseInt(value) / 100).toFixed(2);
    element.value = formatCurrency(parseFloat(value));
    checkBannerDisplay();
}

// Função para fechar o modal
function closeModal() {
    document.getElementById('bannerModal').style.display = 'none';
}

async function calculate() {

    const initialAmountElement = document.getElementById('initialAmount');
    const monthlyAmountElement = document.getElementById('monthlyAmount');
    const interestRateElement = document.getElementById('interestRate');
    const investmentTimeElement = document.getElementById('investmentTime');

    if (!initialAmountElement.value || !monthlyAmountElement.value || !interestRateElement.value || !investmentTimeElement.value) {
        alert('Por favor, preencha todos os campos.');
        return;
    }

    //clearGraphsAndTable();

    const initialAmount = parseCurrency(document.getElementById('initialAmount').value);
    const monthlyAmount = parseCurrency(document.getElementById('monthlyAmount').value);
    const interestRate = parseFloat(document.getElementById('interestRate').value);
    const rateType = document.getElementById('rateType').value;
    const investmentTime = parseFloat(document.getElementById('investmentTime').value);
    const timeUnit = document.getElementById('timeUnit').value;

    const { inflationRate } = simulateRates(); //adicionar novos índices

    let months = timeUnit === 'years' ? investmentTime * 12 : investmentTime;
    let monthlyRate = rateType === 'annual' ? (interestRate / 100) / 12 : interestRate / 100;
    let monthlyInflationRate = inflationRate / 12;
    //let monthlyCdbRate = cdbRate / 12;
   //let monthlyDollarRate = dollarRate / 12;

    let totalInvested = initialAmount;
    let totalInterest = 0;
    let totalAmount = initialAmount;
    //let savingsTotal = initialAmount;
    //let savingsData = [];
    let breakdownHTML = '';
    let monthlyData = [];
    let aporteData = [];
    let rendimentoData = [];
    //let cdbData = [];
    let inflationData = [];
    //let dollarData = [];
    //let cdbTotal = initialAmount;
    //let inflationTotal = initialAmount;
    //let dollarTotal = initialAmount;

    for (let i = 0; i < months; i++) {
        totalAmount += monthlyAmount;
        totalInvested += monthlyAmount;
        let interest = totalAmount * monthlyRate;
        totalInterest += interest;
        totalAmount += interest;

        breakdownHTML += `<tr>
            <td>${i + 1}</td>
            <td>${formatCurrency(monthlyAmount)}</td>
            <td>${formatCurrency(interest)}</td>
            <td>${formatCurrency(totalAmount)}</td>
        </tr>`;

        monthlyData.push(i + 1);
        aporteData.push(totalInvested);
        rendimentoData.push(totalAmount);
        inflationData.push(totalInterest);
    }

    /*for (let i = 0; i < months; i++) {
        savingsTotal += monthlyAmount * (1 + savingsRate / 100);
        savingsData.push(savingsTotal.toFixed(2));
        totalAmount += monthlyAmount;
        totalInvested += monthlyAmount;
        let interest = totalAmount * monthlyRate;
        totalInterest += interest;
        totalAmount += interest;

        cdbTotal += monthlyAmount + (cdbTotal * monthlyCdbRate);
        inflationTotal += monthlyAmount + (inflationTotal * monthlyInflationRate);
        dollarTotal += monthlyAmount + (dollarTotal * monthlyDollarRate);

        breakdownHTML += `<tr>
            <td>${i + 1}</td>
            <td>${formatCurrency(monthlyAmount)}</td>
            <td>${formatCurrency(interest)}</td>
            <td>${formatCurrency(totalAmount)}</td>
        </tr>`;

        monthlyData.push(i + 1);
        aporteData.push(monthlyAmount);
        rendimentoData.push(interest);
        cdbData.push(cdbTotal.toFixed(2));
        inflationData.push(inflationTotal.toFixed(2));
        dollarData.push(dollarTotal.toFixed(2));
    }*/

    document.getElementById('finalValue').innerText = `Valor Total Final: ${formatCurrency(totalAmount)}`;
    document.getElementById('totalInvested').innerText = `Total Investido: ${formatCurrency(totalInvested)}`;
    document.getElementById('totalInterest').innerText = `Total de Juros: ${formatCurrency(totalInterest)}`;
    document.querySelector('#breakdownTable tbody').innerHTML = breakdownHTML;

    document.getElementById('resultsDiv').style.display = 'block';

    new Chart(document.getElementById('investmentChart').getContext('2d'), {
        type: 'line',
        data: {
            labels: monthlyData,
            datasets: [
                {
                    label: 'Valor Total Investido',
                    data: aporteData,
                    borderColor: '#7DB667',
                    borderWidth: 1,
                    fill: false
                },
                {
                    label: 'Valor Total Final',
                    data: rendimentoData,
                    borderColor: 'green',
                    borderWidth: 1,
                    fill: false
                },
                {
                    label: 'Total de Juros',
                    data: inflationData,
                    borderColor: 'black',
                    borderWidth: 1,
                    fill: false
                },
                /*{
                    label: 'Inflação',
                    data: inflationData,
                    borderColor: 'red',
                    borderWidth: 1,
                    fill: false
                }*/
            ]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Mês'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Valor (R$)'
                    }
                }
            }
        }
    });

    new Chart(document.getElementById('pieChart').getContext('2d'), {
        type: 'pie',
        data: {
            labels: ['Valor Total Investido', 'Total de Juros'], // Labels atualizados
            datasets: [{
                data: [totalInvested, totalInterest], // Dados atualizados
                backgroundColor: ['#7DB667', '#FF6384'], // Cores correspondentes
                hoverBackgroundColor: ['#7DB667', '#FF6384'] // Cores de hover correspondentes
            }]
        },
        options: {
            responsive: true
        }
    });
    // Verificação para exibir o modal de banner
      // Exibir o banner se o valor total final for igual ou superior a 350.000
    if (totalAmount >= 350000) {
        document.getElementById('banner').style.display = 'block';
    }
}

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

/*function clearGraphsAndTable() {
    // Limpa os gráficos
    var ctx = document.getElementById('investmentChart');
    var chartInstance = new Chart(ctx, {});
    ctx = document.getElementById('pieChart');
    chartInstance = new Chart(ctx, {});

    // Limpa a tabela
    document.querySelector('#breakdownTable tbody').innerHTML = '';
}*/

// Set the default tab to be open
document.getElementById("defaultTab").click();

function formatCurrency(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}